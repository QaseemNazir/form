import React from 'react';

const Cards = () => {
  return (
    <>

    <div className='Main_Card'>
      <div className='All_Cards'>
        <div className='Card_1'>
             <img src='https://www.pngkit.com/png/full/216-2161190_male-png.png' height={300}  width={300} />
             <header style={{fontWeight:'bold',textAlign:'center',fontSize:'20px',fontFamily:'sans-serif'}}>Hello</header>
             <p style={{textAlign:'center',fontSize:'15px',fontWeight:'bold',fontFamily:'monospace'}}>This is your Payment</p>
             <h1 style={{fontSize:'25px',marginLeft:'1%',color:'lightblue'}}>Price 300$</h1>

        </div>

        <div className='Card_2'>
        <img src='https://www.pngkit.com/png/full/216-2161190_male-png.png' height={300}  width={300} />
             <header style={{fontWeight:'bold',textAlign:'center',fontSize:'20px',fontFamily:'sans-serif'}}>Hello</header>
             <p style={{textAlign:'center',fontSize:'15px',fontWeight:'bold',fontFamily:'monospace'}}>This is your Payment</p>
             <h1 style={{fontSize:'25px',marginLeft:'1%',color:'lightblue'}}>Price 300$</h1>

        </div>

        <div className='Card_3'>
        <img  src='https://www.pngkit.com/png/full/216-2161190_male-png.png' height={300}  width={300} style={{backgroundPosition:"100% 100%"}} />
             <header style={{fontWeight:'bold',textAlign:'center',fontSize:'20px',fontFamily:'sans-serif'}}>Hello</header>
             <p style={{textAlign:'center',fontSize:'15px',fontWeight:'bold',fontFamily:'monospace'}}>This is your Payment</p>
             <h1 style={{fontSize:'25px',marginLeft:'1%',color:'lightblue'}}>Price 300$</h1>
        </div>


      </div>
    </div>




    <div className='Main_Card'>
      <div className='All_Cards'>
        <div className='Card_1'>
             <img src='https://www.pngkit.com/png/full/216-2161190_male-png.png' height={300}  width={300} />
             <header style={{fontWeight:'bold',textAlign:'center',fontSize:'20px',fontFamily:'sans-serif'}}>Hello</header>
             <p style={{textAlign:'center',fontSize:'15px',fontWeight:'bold',fontFamily:'monospace'}}>This is your Payment</p>
             <h1 style={{fontSize:'25px',marginLeft:'1%',color:'lightblue'}}>Price 300$</h1>

        </div>

        <div className='Card_2'>
        <img src='https://www.pngkit.com/png/full/216-2161190_male-png.png' height={300}  width={300} />
             <header style={{fontWeight:'bold',textAlign:'center',fontSize:'20px',fontFamily:'sans-serif'}}>Hello</header>
             <p style={{textAlign:'center',fontSize:'15px',fontWeight:'bold',fontFamily:'monospace'}}>This is your Payment</p>
             <h1 style={{fontSize:'25px',marginLeft:'1%',color:'lightblue'}}>Price 300$</h1>

        </div>

        <div className='Card_3'>
        <img  src='https://www.pngkit.com/png/full/216-2161190_male-png.png' height={300}  width={300} />
             <header style={{fontWeight:'bold',textAlign:'center',fontSize:'20px',fontFamily:'sans-serif'}}>Hello</header>
             <p style={{textAlign:'center',fontSize:'15px',fontWeight:'bold',fontFamily:'monospace'}}>This is your Payment</p>
             <h1 style={{fontSize:'25px',marginLeft:'1%',color:'lightblue'}}>Price 300$</h1>
        </div>


      </div>
    </div>





    </>
  )
}

export default Cards
