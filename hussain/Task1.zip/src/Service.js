import React from 'react'

const Service = () => {
  return (
    <>
    <h1> Welcome to Service Page</h1>
   </>
  )
}

export default Service
